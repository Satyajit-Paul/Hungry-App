//
//  RegisterPageViewController.swift
//  Hungry
//
//  Created by cse on 11/24/19.
//  Copyright © 2019 Kuet. All rights reserved.
//

import UIKit

class RegisterPageViewController: UIViewController {

    @IBOutlet weak var userName: UITextField!
    @IBOutlet weak var userPassword: UITextField!
    @IBOutlet weak var userConfirmPassword: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func registerButton(_ sender: Any) {
        func displayAlert(userMessage:String)
        {
            // create the alert
            let alert = UIAlertController(title: "Please Check !!!", message: userMessage, preferredStyle: UIAlertControllerStyle.alert);
            
            // add the actions (buttons)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil));
            alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel, handler: nil));
            
            // show the alert
            self.present(alert, animated: true, completion: nil);
        }
        
        //variable declaratin
        
        let name=userName.text!;
        
        let password=userPassword.text!;
        let confirmPassword=userConfirmPassword.text!;
        
        //Check for empty field
        if(name.isEmpty   || password.isEmpty  || confirmPassword.isEmpty){
            //display aleart message
            displayAlert(userMessage : "All field are required");
        
            return;
        }
        //check password match or not
        if(password != confirmPassword)
        {
            displayAlert(userMessage : "Passwords do not match");
            
            return;
        }
        //store data
        UserDefaults.standard.set(name,forKey: "userName");
        
        UserDefaults.standard.set(password,forKey: "userPassword");
        
        //Display alert message with confirmation
        
        let Alert = UIAlertController(title: "Congratulations", message: "Registration successful", preferredStyle: UIAlertControllerStyle.alert);
        //dismiss alert
        let okAction = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default){
            ACTION in self.dismiss(animated: true, completion:nil);
        }
        Alert.addAction(okAction);
        self.present(Alert,animated: true,completion: nil);
  }
}
