//
//  LoginViewController.swift
//  Hungry
//
//  Created by cse on 11/24/19.
//  Copyright © 2019 Kuet. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var userName: UITextField!
    @IBOutlet weak var userPassword: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func loginButton(_ sender: Any) {
        func displayAlert(userMessage:String){
            
            let myAlert = UIAlertController(title: "Please Check !!!", message: userMessage, preferredStyle: UIAlertControllerStyle.alert);
            
            // add the actions (buttons)
            let okAction = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil);
            myAlert.addAction(okAction);
            
            let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel, handler: nil);
            myAlert.addAction(cancelAction);
            // show the alert
            self.present(myAlert, animated: true, completion: nil);
        }
        
        let name = userName.text!;
        let password = userPassword.text!;
        let nameStor = UserDefaults.standard.string(forKey: "userName");
        let passwordStor = UserDefaults.standard.string(forKey:"userPassword");
        
        if(name.isEmpty   || password.isEmpty){
            //display aleart message
            displayAlert(userMessage : "All field are required");
            return;
        }
        if(name == nameStor)
        {
            if(password == passwordStor)
            {
                //save data
                UserDefaults.standard.set(true,forKey: "isUserLoggedIn");
                UserDefaults.standard.synchronize();
                self.dismiss(animated: true, completion:nil);
                
                //alert
                let Alert = UIAlertController(title: "Thanks ", message: "Your Login successful", preferredStyle: UIAlertControllerStyle.alert);
                //dismiss alert
                
                let okAction = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil);
                Alert.addAction(okAction);
                self.present(Alert,animated: true,completion: nil);
                
            }
            else
            {
                displayAlert(userMessage: "Password Not match");
            }
        }
        else
        {
            displayAlert(userMessage: "Username or Passwords do not match");
        }
        
    }
   

}
