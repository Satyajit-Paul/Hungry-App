//
//  ViewController.swift
//  Hungry
//
//  Created by cse on 11/24/19.
//  Copyright © 2019 Kuet. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewDidAppear(_ animated: Bool) {
        
        let isuserLoggedIn = UserDefaults.standard.bool(forKey: "isUserLoggedIn");
        if(!isuserLoggedIn)
        {
            self.performSegue(withIdentifier: "loginView", sender: self);
        }
    }
    
    @IBAction func logoutbutton(_ sender: Any) {
        UserDefaults.standard.set(false,forKey: "isUserLoggedIn");
        UserDefaults.standard.synchronize();
        
         self.performSegue(withIdentifier: "loginView", sender: self);
     
    }

}

